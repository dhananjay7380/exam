package com.app.pojos;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name="bajaj")
public class Exam extends BaseEntity {
	@Column
	private boolean status;
	@Column(length = 30)
	private String emailId;
	@Column(length = 30)
	private String rollNumber;
	@Column
	private int numArray[];
	@Column
	private String charArray[];
	

	public Exam() {
		// TODO Auto-generated constructor stub
	}

      

	public Exam(boolean status, String emailId, String rollNumber, int[] numArray, String[] charArray) {
		super();
		this.status = status;
		this.emailId = emailId;
		this.rollNumber = rollNumber;
		this.numArray = numArray;
		this.charArray = charArray;
	}



	

	public boolean isStatus() {
		return status;
	}



	public void setStatus(boolean status) {
		this.status = status;
	}



	public String getEmailId() {
		return emailId;
	}



	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}



	public String getRollNumber() {
		return rollNumber;
	}



	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}



	public int[] getNumArray() {
		return numArray;
	}



	public void setNumArray(int[] numArray) {
		this.numArray = numArray;
	}



	public String[] getCharArray() {
		return charArray;
	}



	public void setCharArray(String[] charArray) {
		this.charArray = charArray;
	}



	@Override
	public String toString() {
		return "Employee [status=" + status + ", emailId=" + emailId + ", rollNumber=" + rollNumber + ", numArray="
				+ Arrays.toString(numArray) + ", charArray=" + Arrays.toString(charArray) + "]";
	}



	

}
