package com.app.pojos;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

@MappedSuperclass
public class BaseEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer user_Id;

	public Integer getId() {
		return user_Id;
	}

	public void setId(Integer user_Id) {
		this.user_Id = user_Id;
	}

}
