package com.app.service;

import java.util.List;

import com.app.pojos.Exam;

public interface IExamService {
	List<Exam> getAllEmployees();
	Exam addEmployeeDetails(Exam transientEmp);
}
