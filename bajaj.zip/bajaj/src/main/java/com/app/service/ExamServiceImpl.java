package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.ExamRepository;
import com.app.pojos.Exam;

@Service
@Transactional
public class ExamServiceImpl implements IExamService {
	//dependency : dao layer i/f
	@Autowired
	private ExamRepository employeeRepo;

	@Override
	public List<Exam> getAllEmployees() {
		// Method of JpaRepository : super i/f dao layer i/f
		//Inherited API : public List<T> findAll();
		return employeeRepo.findAll();
	}

	@Override
	public Exam addEmployeeDetails(Exam transientEmp) {
		// TODO Auto-generated method stub
		return employeeRepo.save(transientEmp);
	}//what will method ret ? DETACHED emp ---> to the controller
	

}
