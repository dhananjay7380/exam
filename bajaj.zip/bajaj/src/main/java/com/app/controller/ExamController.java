package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.pojos.Exam;
import com.app.service.IExamService;

//@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/testbfhl.herokuapp.com/bfhl")
public class ExamController {
	//dependency : service layer i/f
	@Autowired
	private IExamService employeeService;
	
	public ExamController() {
		System.out.println("in ctor of " + getClass());
	}
	//add request handling method to send all emps to the caller(front end) : getting resources : GET
	@GetMapping
	public List<Exam> getAllEmpDetails()
	{
		System.out.println("in get all emps");
		return employeeService.getAllEmployees();
	}
	//add request handling method to insert new emp detaild(create a new resource) : POST
	@PostMapping
	public Exam addEmpDetails(@RequestBody Exam e)
	{
		System.out.println("in add emp "+e);
		return employeeService.addEmployeeDetails(e);
	}
}
